Deliverables of version 1.0
